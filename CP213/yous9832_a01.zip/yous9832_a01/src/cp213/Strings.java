package cp213;

/**
 * @author Your name and id here
 * @version 2025-05-04
 */
public class Strings {
    // Constants
    public static final String VOWELS = "aeiouAEIOU";

    /**
     * Determines if string is a "palindrome".
     */
    public static boolean isPalindrome(final String string) {
        StringBuilder cleaned = new StringBuilder();

        for (char ch : string.toCharArray()) {
            if (Character.isLetter(ch)) {
                cleaned.append(Character.toLowerCase(ch));
            }
        }

        String cleanedStr = cleaned.toString();
        String reversedStr = cleaned.reverse().toString();

        return cleanedStr.equals(reversedStr);
    }

    /**
     * Determines if name is a valid Java variable name.
     */
    public static boolean isValid(final String name) {
        if (name == null || name.isEmpty()) return false;
        if (name.equals("_")) return false;

        char firstChar = name.charAt(0);
        if (!Character.isLetter(firstChar) && firstChar != '_') return false;

        for (int i = 1; i < name.length(); i++) {
            char ch = name.charAt(i);
            if (!Character.isLetterOrDigit(ch) && ch != '_') return false;
        }

        return true;
    }

    /**
     * Converts a word to Pig Latin.
     */
    public static String pigLatin(String word) {
        if (word == null || word.isEmpty()) return word;

        boolean startsWithUpper = Character.isUpperCase(word.charAt(0));
        String lowerWord = word.toLowerCase();

        if (VOWELS.indexOf(lowerWord.charAt(0)) >= 0) {
            String result = lowerWord + "way";
            return startsWithUpper ? capitalize(result) : result;
        } else {
            int index = 0;
            while (index < lowerWord.length()) {
                char ch = lowerWord.charAt(index);
                if (VOWELS.indexOf(ch) >= 0 || (ch == 'y' && index != 0)) {
                    break;
                }
                index++;
            }

            if (index == 0) {
                return word + "ay";
            }

            String result = lowerWord.substring(index) + lowerWord.substring(0, index) + "ay";
            return startsWithUpper ? capitalize(result) : result;
        }
    }

    // Helper to capitalize the first letter
    private static String capitalize(String word) {
        if (word.isEmpty()) return word;
        return Character.toUpperCase(word.charAt(0)) + word.substring(1);
    }
}
