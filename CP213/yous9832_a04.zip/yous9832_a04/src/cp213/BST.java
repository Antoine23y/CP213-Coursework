package cp213;

import java.util.ArrayList;

/**
 * Implements a Binary Search Tree.
 *
 * @author Antoine Youssef
 * @author David Brown
 * @version 2025-05-04
 * @param <T> the data structure data type
 */
public class BST<T extends Comparable<T>> {

    // Attributes.
    /**
     * Count of comparisons performed by tree.
     */
    protected int comparisons = 0;
    /**
     * Root node of the tree.
     */
    protected TreeNode<T> root = null;
    /**
     * Number of nodes in the tree.
     */
    protected int size = 0;

    /**
     * Auxiliary method for {@code equals}. Determines whether two subtrees are
     * identical in node data and height.
     *
     * @param source Node of this BST.
     * @param target Node of that BST.
     * @return true if source and target are identical in node data and height.
     */
    protected boolean equalsAux(final TreeNode<T> source, final TreeNode<T> target) {
        boolean isEqual = true;

        if (source == null && target == null) {
            // Both nodes are null - they are equal
            isEqual = true;
        } else if (source == null || target == null) {
            // One is null, the other is not - they are not equal
            isEqual = false;
        } else {
            // Both nodes exist - check data, count, height, and children
            if (!source.getCountedArtifact().equals(target.getCountedArtifact()) ||
                    source.getCountedArtifact().getCount() != target.getCountedArtifact().getCount() ||
                    source.getHeight() != target.getHeight()) {
                isEqual = false;
            } else {
                // Recursively check left and right subtrees
                isEqual = this.equalsAux(source.getLeft(), target.getLeft()) &&
                        this.equalsAux(source.getRight(), target.getRight());
            }
        }

        return isEqual;
    }

    /**
     * Auxiliary method for insert. Inserts data into this BST.
     *
     * @param node            The current node (TreeNode).
     * @param countedArtifact Data to be inserted into the tree.
     * @return The inserted node.
     */
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedArtifact<T> countedArtifact) {

        if (node == null) {
            // Base case - add a new node containing the data.
            node = new TreeNode<T>(countedArtifact);
            node.getCountedArtifact().incrementCount();
            this.size++;
        } else {
            // Compare the node data against the insert data.
            final int result = node.getCountedArtifact().compareTo(countedArtifact);

            if (result > 0) {
                // General case - check the left subtree.
                node.setLeft(this.insertAux(node.getLeft(), countedArtifact));
            } else if (result < 0) {
                // General case - check the right subtree.
                node.setRight(this.insertAux(node.getRight(), countedArtifact));
            } else {
                // Base case - data is already in the tree, increment its count
                node.getCountedArtifact().incrementCount();
            }
        }
        node.updateHeight();
        return node;
    }

    /**
     * Auxiliary method for valid. Determines if a subtree based on node is a valid
     * subtree.
     *
     * @param node    The root of the subtree to test for validity.
     * @param minNode The node of the minimum data in the current subtree.
     * @param maxNode The node of the maximum data in the current subtree.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    protected boolean isValidAux(final TreeNode<T> node, TreeNode<T> minNode, TreeNode<T> maxNode) {
        boolean isValid = true;

        if (node != null) {
            // Check BST property: node's data must be greater than min and less than max
            if (minNode != null && node.getCountedArtifact().compareTo(minNode.getCountedArtifact()) <= 0) {
                isValid = false;
            } else if (maxNode != null && node.getCountedArtifact().compareTo(maxNode.getCountedArtifact()) >= 0) {
                isValid = false;
            } else {
                // Check height property: node height = max(left height, right height) + 1
                int leftHeight = this.nodeHeight(node.getLeft());
                int rightHeight = this.nodeHeight(node.getRight());
                int expectedHeight = Math.max(leftHeight, rightHeight) + 1;

                if (node.getHeight() != expectedHeight) {
                    isValid = false;
                } else {
                    // Recursively check left and right subtrees
                    isValid = this.isValidAux(node.getLeft(), minNode, node) &&
                            this.isValidAux(node.getRight(), node, maxNode);
                }
            }
        }

        return isValid;
    }

    /**
     * Returns the height of a given TreeNode. Required for when TreeNode is null.
     *
     * @param node The TreeNode to determine the height of.
     * @return The height attribute of node, 0 if node is null.
     */
    protected int nodeHeight(final TreeNode<T> node) {
        return node != null ? node.getHeight() : 0;
    }

    /**
     * Auxiliary method for remove. Removes data from this BST.
     *
     * @param node            The current node (TreeNode).
     * @param countedArtifact Data to be removed from the tree.
     * @return The replacement node.
     */
    protected TreeNode<T> removeAux(TreeNode<T> node, final CountedArtifact<T> countedArtifact) {
        if (node == null) {
            // Base case - data not found
            return null;
        }

        // Compare the node data against the removal data
        final int result = node.getCountedArtifact().compareTo(countedArtifact);

        if (result > 0) {
            // Data is in the left subtree
            node.setLeft(this.removeAux(node.getLeft(), countedArtifact));
        } else if (result < 0) {
            // Data is in the right subtree
            node.setRight(this.removeAux(node.getRight(), countedArtifact));
        } else {
            // Found the node to remove
            if (node.getCountedArtifact().getCount() > 1) {
                // Just decrement the count
                node.getCountedArtifact().decrementCount();
            } else {
                // Remove the node entirely
                this.size--;

                if (node.getLeft() == null) {
                    // Node has only right child or no children
                    return node.getRight();
                } else if (node.getRight() == null) {
                    // Node has only left child
                    return node.getLeft();
                } else {
                    // Node has two children - find inorder successor
                    TreeNode<T> successor = node.getRight();
                    while (successor.getLeft() != null) {
                        successor = successor.getLeft();
                    }

                    // Copy successor's data to current node
                    CountedArtifact<T> successorData = successor.getCountedArtifact();
                    CountedArtifact<T> newData = new CountedArtifact<T>(successorData.getArtifact(),
                            successorData.getCount());

                    // Create a new node with the successor's data
                    TreeNode<T> newNode = new TreeNode<T>(newData);
                    newNode.setLeft(node.getLeft());
                    newNode.setRight(node.getRight());
                    node = newNode;

                    // Remove the successor (use key with count 0)
                    CountedArtifact<T> keyToRemove = new CountedArtifact<T>(successorData.getArtifact());
                    node.setRight(this.removeAux(node.getRight(), keyToRemove));
                }
            }
        }

        if (node != null) {
            // Update height
            node.updateHeight();
        }

        return node;
    }

    /**
     * Determines if this BST contains key.
     *
     * @param key The key to search for.
     * @return true if this contains key, false otherwise.
     */
    public boolean contains(final CountedArtifact<T> key) {
        TreeNode<T> current = this.root;
        boolean found = false;

        while (current != null && !found) {
            this.comparisons++;
            final int result = current.getCountedArtifact().compareTo(key);

            if (result > 0) {
                // Key is in the left subtree
                current = current.getLeft();
            } else if (result < 0) {
                // Key is in the right subtree
                current = current.getRight();
            } else {
                // Found the key
                found = true;
            }
        }

        return found;
    }

    /**
     * Determines whether two trees are identical.
     *
     * @param target The tree to compare this BST against.
     * @return true if this and target contain nodes that match in position, data,
     *         count, and height, false otherwise.
     */
    public boolean equals(final BST<T> target) {
        boolean isEqual = false;

        if (this.size == target.size) {
            isEqual = this.equalsAux(this.root, target.root);
        }
        return isEqual;
    }

    /**
     * Get number of comparisons executed by the retrieve method.
     *
     * @return comparisons
     */
    public int getComparisons() {
        return this.comparisons;
    }

    /**
     * Returns the height of the root node of this tree.
     *
     * @return height of root node, 0 if the root node is null.
     */
    public int getHeight() {
        return this.root != null ? this.root.getHeight() : 0;
    }

    /**
     * Returns the number of nodes in the tree.
     *
     * @return number of nodes in this tree.
     */
    public int getSize() {
        return this.size;
    }

    /**
     * Returns a list of the data in the current tree. The list contents are in
     * order from smallest to largest.
     *
     * Not thread safe as it assumes contents of the tree are not changed by an
     * external thread during the loop.
     *
     * @return The contents of this tree as a list of data.
     */
    public ArrayList<CountedArtifact<T>> inOrder() {
        if (this.root == null) {
            return new ArrayList<>();
        }
        return this.root.inOrder();
    }

    /**
     * Inserts data into this tree.
     *
     * @param countedArtifact Data to store.
     */
    public void insert(final CountedArtifact<T> countedArtifact) {
        this.root = this.insertAux(this.root, countedArtifact);
        return;
    }

    /**
     * Determines if this tree is empty.
     *
     * @return true if this tree is empty, false otherwise.
     */
    public boolean isEmpty() {
        return this.root == null;
    }

    /**
     * Determines if this tree is a valid BST; i.e. a node's left child data is
     * smaller than its data, and its right child data is greater than its data, and
     * a node's height is equal to the maximum of the heights of its two children
     * (empty child nodes have a height of 0), plus 1.
     *
     * @return true if this tree is a valid BST, false otherwise.
     */
    public boolean isValid() {
        return this.isValidAux(this.root, null, null);
    }

    /**
     * Returns a list of the data in the current tree. The list contents are in node
     * level order starting from the root node. Helps determine the structure of the
     * tree.
     *
     * Not thread safe as it assumes contents of the tree are not changed by an
     * external thread during the loop.
     *
     * @return this tree data as a list of data.
     */
    public ArrayList<CountedArtifact<T>> levelOrder() {
        if (this.root == null) {
            return new ArrayList<>();
        }
        return this.root.levelOrder();
    }

    /**
     * Returns a list of the data in the current tree. The list contents are in node
     * preorder.
     *
     * Not thread safe as it assumes contents of the tree are not changed by an
     * external thread during the loop.
     *
     * @return The contents of this tree as a list of data.
     */
    public ArrayList<CountedArtifact<T>> preOrder() {
        if (this.root == null) {
            return new ArrayList<>();
        }
        return this.root.preOrder();
    }

    /**
     * Removes data from the tree. Decrements the node count, and if the count is 0,
     * removes the node entirely.
     *
     * @param countedArtifact Data to decrement or remove.
     */
    public void remove(final CountedArtifact<T> countedArtifact) {
        this.root = this.removeAux(this.root, countedArtifact);
        return;
    }

    /**
     * Resets the comparison count to 0.
     */
    public void resetComparisons() {
        this.comparisons = 0;
        return;
    }

    /**
     * Retrieves a copy of data matching key (key should have data count of 0).
     * Returning a complete CountedArtifact gives access to the data and its count.
     *
     * @param key The key to look for.
     * @return The complete CountedArtifact that matches key, null otherwise.
     */
    public CountedArtifact<T> retrieve(final CountedArtifact<T> key) {
        TreeNode<T> current = this.root;
        CountedArtifact<T> result = null;

        while (current != null) {
            this.comparisons++;
            final int comparison = current.getCountedArtifact().compareTo(key);

            if (comparison > 0) {
                // Key is in the left subtree
                current = current.getLeft();
            } else if (comparison < 0) {
                // Key is in the right subtree
                current = current.getRight();
            } else {
                // Found the key - return a copy
                result = new CountedArtifact<T>(current.getCountedArtifact());
                break;
            }
        }

        return result;
    }
}
