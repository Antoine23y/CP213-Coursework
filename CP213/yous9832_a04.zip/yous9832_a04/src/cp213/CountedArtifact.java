package cp213;

/**
 * Stores a artifact and an occurrence count for that artifact. The artifact
 * must be Comparable so that it can be compared and sorted against other datas
 * of the same type.
 *
 * @author David Brown
 * @version 2025-05-04
 */
public class CountedArtifact<T extends Comparable<T>> implements Comparable<CountedArtifact<T>> {

    // Attributes.
    private int count = 0; // artifact count
    private T artifact = null; // artifact

    /**
     * Copy constructor.
     *
     * @param source Another CountedArtifact object.
     */
    public CountedArtifact(final CountedArtifact<T> source) {
	this.artifact = source.artifact;
	this.count = source.count;
    }

    /**
     * Constructor for key version of object. (artifact count defaults to 0)
     *
     * @param artifact The object to be counted.
     */
    public CountedArtifact(final T artifact) {
	this.artifact = artifact;
    }

    /**
     * Constructor.
     *
     * @param artifact The object to be counted.
     * @param count    The object count.
     */
    public CountedArtifact(final T data, final int count) {
	this.artifact = data;
	this.count = count;
    }

    /**
     * Comparison method for objects. Compares only the stored objects, counts are
     * ignored. Returns:
     * <ul>
     * <li>0 if this equals target</li>
     * <li>&lt; 0 if this precedes target</li>
     * <li>&gt; 0 if this follows target</li>
     * </ul>
     *
     * @param target CountedArtifact object to compare against.
     * @return Comparison result.
     */
    @Override
    public int compareTo(CountedArtifact<T> target) {
	return this.artifact.compareTo(target.artifact);
    }

    /**
     * Decrements the artifact count.
     */
    public void decrementCount() {
	this.count--;
    }

    /**
     * Returns this artifact count.
     *
     * @return this artifact count.
     */
    public int getCount() {
	return this.count;
    }

    /**
     * Returns this artifact.
     *
     * @return this artifact.
     */
    public T getArtifact() {
	return this.artifact;
    }

    /**
     * Returns a copy of the current object.
     *
     * @return
     */
    public CountedArtifact<T> copy() {
	return new CountedArtifact<T>(this.artifact, this.count);
    }

    /**
     * Increments the artifact count.
     */
    public void incrementCount() {
	this.count++;
    }

    /**
     * Sets the artifact count.
     *
     * @param count the new artifact count.
     */
    public void setCount(final int count) {
	this.count = count;
	return;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
	return String.format("{%s: %d}", this.artifact.toString(), this.count);
    }

}
