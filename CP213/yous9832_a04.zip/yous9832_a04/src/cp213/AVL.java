package cp213;

/**
 * Implements an AVL (Adelson-Velsky Landis) tree. Extends BST.
 *
 * @author Antoine Youssef
 * @author David Brown
 * @version 2025-05-04
 * @param <T> the data structure data type
 */
public class AVL<T extends Comparable<T>> extends BST<T> {

    /**
     * Returns the balance data of node. If greater than 1, then left heavy, if less
     * than -1, then right heavy. If in the range -1 to 1 inclusive, the node is
     * balanced. Used to determine whether to rotate a node upon insertion.
     *
     * @param node The TreeNode to analyze for balance.
     * @return A balance number.
     */
    private int balance(final TreeNode<T> node) {
        if (node == null) {
            return 0;
        }
        return this.nodeHeight(node.getLeft()) - this.nodeHeight(node.getRight());
    }

    /**
     * Rebalances the current node if its children are not balanced.
     *
     * @param node the node to rebalance
     * @return replacement for the rebalanced node
     */
    private TreeNode<T> rebalance(TreeNode<T> node) {
        if (node == null) {
            return null;
        }

        int balance = this.balance(node);

        if (balance > 1) {
            // Left heavy
            if (this.balance(node.getLeft()) < 0) {
                // Left-Right case
                node.setLeft(this.rotateLeft(node.getLeft()));
            }
            // Left-Left case
            node = this.rotateRight(node);
        } else if (balance < -1) {
            // Right heavy
            if (this.balance(node.getRight()) > 0) {
                // Right-Left case
                node.setRight(this.rotateRight(node.getRight()));
            }
            // Right-Right case
            node = this.rotateLeft(node);
        }

        return node;
    }

    /**
     * Performs a left rotation around node.
     *
     * @param node The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateLeft(final TreeNode<T> node) {
        if (node == null || node.getRight() == null) {
            return node;
        }

        TreeNode<T> newRoot = node.getRight();
        node.setRight(newRoot.getLeft());
        newRoot.setLeft(node);

        // Update heights
        node.updateHeight();
        newRoot.updateHeight();

        return newRoot;
    }

    /**
     * Performs a right rotation around node.
     *
     * @param node The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateRight(final TreeNode<T> node) {
        if (node == null || node.getLeft() == null) {
            return node;
        }

        TreeNode<T> newRoot = node.getLeft();
        node.setLeft(newRoot.getRight());
        newRoot.setRight(node);

        // Update heights
        node.updateHeight();
        newRoot.updateHeight();

        return newRoot;
    }

    /**
     * Auxiliary method for insert. Inserts data into this AVL. Same as BST
     * insertion with addition of rebalance of nodes.
     *
     * @param node            The current node (TreeNode).
     * @param countedArtifact Data to be inserted into the node.
     * @return The inserted node.
     */
    @Override
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedArtifact<T> countedArtifact) {
        if (node == null) {
            // Base case - add a new node containing the data.
            node = new TreeNode<T>(countedArtifact);
            node.getCountedArtifact().incrementCount();
            this.size++;
        } else {
            // Compare the node data against the insert data.
            final int result = node.getCountedArtifact().compareTo(countedArtifact);

            if (result > 0) {
                // General case - check the left subtree.
                node.setLeft(this.insertAux(node.getLeft(), countedArtifact));
            } else if (result < 0) {
                // General case - check the right subtree.
                node.setRight(this.insertAux(node.getRight(), countedArtifact));
            } else {
                // Base case - data is already in the tree, increment its count
                node.getCountedArtifact().incrementCount();
            }
        }

        // Update height and rebalance
        node.updateHeight();
        node = this.rebalance(node);

        return node;
    }

    /**
     * Auxiliary method for valid. Determines if a subtree based on node is a valid
     * subtree. An AVL must meet the BST validation conditions, and additionally be
     * balanced in all its subtrees - i.e. the difference in height between any two
     * children must be no greater than 1.
     *
     * @param node The root of the subtree to test for validity.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    @Override
    protected boolean isValidAux(final TreeNode<T> node, TreeNode<T> minNode, TreeNode<T> maxNode) {
        boolean isValid = true;

        if (node != null) {
            // Check BST property first
            if (minNode != null && node.getCountedArtifact().compareTo(minNode.getCountedArtifact()) <= 0) {
                isValid = false;
            } else if (maxNode != null && node.getCountedArtifact().compareTo(maxNode.getCountedArtifact()) >= 0) {
                isValid = false;
            } else {
                // Check AVL balance property: balance factor must be between -1 and 1
                int balanceFactor = this.balance(node);
                if (balanceFactor < -1 || balanceFactor > 1) {
                    isValid = false;
                } else {
                    // Recursively check left and right subtrees
                    isValid = this.isValidAux(node.getLeft(), minNode, node)
                            && this.isValidAux(node.getRight(), node, maxNode);
                }
            }
        }

        return isValid;
    }

    /**
     * Determines whether two AVLs are identical.
     *
     * @param target The AVL to compare this AVL against.
     * @return true if this AVL and target contain nodes that match in position,
     *         data, count, and height, false otherwise.
     */
    public boolean equals(final AVL<T> target) {
        return super.equals(target);
    }

    /**
     * Auxiliary method for remove. Removes data from this BST. Same as BST removal
     * with addition of rebalance of nodes.
     *
     * @param node            The current node (TreeNode).
     * @param countedArtifact Data removed from the tree.
     * @return The replacement node.
     */
    @Override
    protected TreeNode<T> removeAux(TreeNode<T> node, final CountedArtifact<T> countedArtifact) {
        if (node == null) {
            // Base case - data not found
            return null;
        }

        // Compare the node data against the removal data
        final int result = node.getCountedArtifact().compareTo(countedArtifact);

        if (result > 0) {
            // Data is in the left subtree
            node.setLeft(this.removeAux(node.getLeft(), countedArtifact));
        } else if (result < 0) {
            // Data is in the right subtree
            node.setRight(this.removeAux(node.getRight(), countedArtifact));
        } else {
            // Found the node to remove
            if (node.getCountedArtifact().getCount() > 1) {
                // Just decrement the count
                node.getCountedArtifact().decrementCount();
            } else {
                // Remove the node entirely
                this.size--;

                if (node.getLeft() == null) {
                    // Node has only right child or no children
                    return node.getRight();
                } else if (node.getRight() == null) {
                    // Node has only left child
                    return node.getLeft();
                } else {
                    // Node has two children - find inorder successor
                    TreeNode<T> successor = node.getRight();
                    while (successor.getLeft() != null) {
                        successor = successor.getLeft();
                    }

                    // Copy successor's data to current node
                    CountedArtifact<T> successorData = successor.getCountedArtifact();
                    CountedArtifact<T> newData = new CountedArtifact<T>(successorData.getArtifact(),
                            successorData.getCount());

                    // Create a new node with the successor's data
                    TreeNode<T> newNode = new TreeNode<T>(newData);
                    newNode.setLeft(node.getLeft());
                    newNode.setRight(node.getRight());
                    node = newNode;

                    // Remove the successor (use key with count 0)
                    CountedArtifact<T> keyToRemove = new CountedArtifact<T>(successorData.getArtifact());
                    node.setRight(this.removeAux(node.getRight(), keyToRemove));
                }
            }
        }

        if (node != null) {
            // Update height and rebalance
            node.updateHeight();
            node = this.rebalance(node);
        }

        return node;
    }

}
