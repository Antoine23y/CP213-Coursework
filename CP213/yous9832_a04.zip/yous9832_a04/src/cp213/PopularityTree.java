package cp213;

/**
 * Implements a Popularity Tree. Extends BST.
 *
 * @author Antoine Youssef
 * @author David Brown
 * @version 2025-05-04
 * @param <T> the data structure data type
 */
public class PopularityTree<T extends Comparable<T>> extends BST<T> {

    /**
     * Auxiliary method for valid. May force node rotation if the retrieval count of
     * the located node data is incremented.
     *
     * @param node The node to examine for key.
     * @param key  The data to search for. Count is updated to count in matching
     *             node data if key is found.
     * @return The updated node.
     */
    private TreeNode<T> retrieveAux(TreeNode<T> node, final CountedArtifact<T> key) {
        if (node == null) {
            // Key not found
            return null;
        }

        this.comparisons++;
        final int result = node.getCountedArtifact().compareTo(key);

        if (result > 0) {
            // Key is in left subtree
            TreeNode<T> leftResult = this.retrieveAux(node.getLeft(), key);
            if (leftResult != null) {
                // Found in left subtree, check if we need to rotate
                TreeNode<T> leftChild = node.getLeft();
                if (leftChild != null
                        && leftChild.getCountedArtifact().getCount() > node.getCountedArtifact().getCount()) {
                    // Left child is now more popular, rotate right
                    node = this.rotateRight(node);
                }
            }
        } else if (result < 0) {
            // Key is in right subtree
            TreeNode<T> rightResult = this.retrieveAux(node.getRight(), key);
            if (rightResult != null) {
                // Found in right subtree, check if we need to rotate
                TreeNode<T> rightChild = node.getRight();
                if (rightChild != null
                        && rightChild.getCountedArtifact().getCount() > node.getCountedArtifact().getCount()) {
                    // Right child is now more popular, rotate left
                    node = this.rotateLeft(node);
                }
            }
        } else {
            // Found the key - increment its count
            node.getCountedArtifact().incrementCount();
            // Copy the count back to the key for return value
            key.setCount(node.getCountedArtifact().getCount());
        }

        return node;
    }

    /**
     * Performs a left rotation around node.
     *
     * @param parent The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateLeft(final TreeNode<T> parent) {
        if (parent == null || parent.getRight() == null) {
            return parent;
        }

        TreeNode<T> newRoot = parent.getRight();
        parent.setRight(newRoot.getLeft());
        newRoot.setLeft(parent);

        // Update heights
        parent.updateHeight();
        newRoot.updateHeight();

        return newRoot;
    }

    /**
     * Performs a right rotation around {@code node}.
     *
     * @param parent The subtree to rotate.
     * @return The new root of the subtree.
     */
    private TreeNode<T> rotateRight(final TreeNode<T> parent) {
        if (parent == null || parent.getLeft() == null) {
            return parent;
        }

        TreeNode<T> newRoot = parent.getLeft();
        parent.setLeft(newRoot.getRight());
        newRoot.setRight(parent);

        // Update heights
        parent.updateHeight();
        newRoot.updateHeight();

        return newRoot;
    }

    /**
     * Replaces BST insertAux - does not increment count on repeated insertion.
     * Counts are incremented only on retrieve.
     */
    @Override
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedArtifact<T> countedArtifact) {
        if (node == null) {
            // Base case - add a new node containing the data.
            node = new TreeNode<T>(countedArtifact);
            // Note: Don't increment count here - counts are only incremented on retrieve
            this.size++;
        } else {
            // Compare the node data against the insert data.
            final int result = node.getCountedArtifact().compareTo(countedArtifact);

            if (result > 0) {
                // General case - check the left subtree.
                node.setLeft(this.insertAux(node.getLeft(), countedArtifact));
            } else if (result < 0) {
                // General case - check the right subtree.
                node.setRight(this.insertAux(node.getRight(), countedArtifact));
            }
            // Note: If data already exists (result == 0), we don't increment count
            // Counts are only incremented on retrieve operations
        }

        node.updateHeight();
        return node;
    }

    /**
     * Auxiliary method for valid. Determines if a subtree based on node is a valid
     * subtree. An Popularity Tree must meet the BST validation conditions, and
     * additionally the counts of any node data must be greater than or equal to the
     * counts of its children.
     *
     * @param node The root of the subtree to test for validity.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    @Override
    protected boolean isValidAux(final TreeNode<T> node, TreeNode<T> minNode, TreeNode<T> maxNode) {
        boolean isValid = true;

        if (node != null) {
            // First check BST properties
            if (minNode != null && node.getCountedArtifact().compareTo(minNode.getCountedArtifact()) <= 0) {
                isValid = false;
            } else if (maxNode != null && node.getCountedArtifact().compareTo(maxNode.getCountedArtifact()) >= 0) {
                isValid = false;
            } else {
                // Check height property
                int leftHeight = this.nodeHeight(node.getLeft());
                int rightHeight = this.nodeHeight(node.getRight());
                int expectedHeight = Math.max(leftHeight, rightHeight) + 1;

                if (node.getHeight() != expectedHeight) {
                    isValid = false;
                } else {
                    // Check popularity property: parent count >= children counts
                    int nodeCount = node.getCountedArtifact().getCount();

                    if (node.getLeft() != null &&
                            node.getLeft().getCountedArtifact().getCount() > nodeCount) {
                        isValid = false;
                    }

                    if (isValid && node.getRight() != null &&
                            node.getRight().getCountedArtifact().getCount() > nodeCount) {
                        isValid = false;
                    }

                    // Recursively check left and right subtrees
                    if (isValid) {
                        isValid = this.isValidAux(node.getLeft(), minNode, node) &&
                                this.isValidAux(node.getRight(), node, maxNode);
                    }
                }
            }
        }

        return isValid;
    }

    /**
     * Determines whether two PopularityTrees are identical.
     *
     * @param target The PopularityTree to compare this PopularityTree against.
     * @return true if this PopularityTree and target contain nodes that match in
     *         position, data, count, and height, false otherwise.
     */
    public boolean equals(final PopularityTree<T> target) {
        return super.equals(target);
    }

    /**
     * Very similar to the BST retrieve, but increments the data count here instead
     * of in the insertion.
     *
     * @param key The key to search for.
     */
    @Override
    public CountedArtifact<T> retrieve(CountedArtifact<T> key) {
        CountedArtifact<T> result = null;

        if (this.root != null) {
            // Create a copy of the key to avoid modifying the original
            CountedArtifact<T> searchKey = new CountedArtifact<T>(key.getArtifact());

            // Perform the search and potentially update the tree structure
            this.root = this.retrieveAux(this.root, searchKey);

            // If the search was successful, return a copy with the updated count
            if (searchKey.getCount() > 0) {
                result = new CountedArtifact<T>(searchKey);
            }
        }

        return result;
    }

}
