package cp213;

/**
 * A single linked list structure of <code>Node T</code> objects. These data
 * objects must be Comparable - i.e. they must provide the compareTo method.
 * Only the <code>T</code> object contained in the priority queue is visible
 * through the standard priority queue methods. Extends the
 * <code>SingleLink</code> class.
 *
 * @author David Brown
 * @version 2025-05-04
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

    /**
     * Searches for the first occurrence of key in this SingleList. Private helper
     * methods - used only by other ADT methods.
     *
     * @param key The object to look for.
     * @return A pointer to the node previous to the node containing key.
     */
    private SingleNode<T> linearSearch(final T key) {

        SingleNode<T> previous = null;
        SingleNode<T> current = this.front;

        while (current != null && current.getArtifact().compareTo(key) != 0) {
            previous = current;
            current = current.getNext();
        }

        return previous;
    }

    /**
     * Appends data to the end of this SingleList.
     *
     * @param artifact The object to append.
     */
    public void append(final T artifact) {
        // Create new node with the artifact
        SingleNode<T> newNode = new SingleNode<>(artifact, null);

        if (this.front == null) {
            // List is empty - new node becomes both front and rear
            this.front = newNode;
            this.rear = newNode;
        } else {
            // List has elements - add to the end
            this.rear.setNext(newNode);
            this.rear = newNode;
        }

        this.length++;
        return;
    }

    /**
     * Removes duplicates from this SingleList. The list contains one and only one
     * of each object formerly present in this SingleList. The first occurrence of
     * each object is preserved.
     */
    public void clean() {
        if (this.front == null) {
            // Empty list - nothing to clean
            return;
        }

        SingleNode<T> current = this.front;

        while (current != null) {
            SingleNode<T> runner = current;

            // Look for duplicates of current.getArtifact()
            while (runner.getNext() != null) {
                if (runner.getNext().getArtifact().compareTo(current.getArtifact()) == 0) {
                    // Found duplicate - remove it
                    SingleNode<T> duplicate = runner.getNext();
                    runner.setNext(duplicate.getNext());

                    // Update rear if we removed the last node
                    if (duplicate == this.rear) {
                        this.rear = runner;
                    }

                    this.length--;
                } else {
                    // Move to next node only if we didn't remove one
                    runner = runner.getNext();
                }
            }
            current = current.getNext();
        }
        return;
    }

    /**
     * Combines contents of two lists into a third. Values are alternated from the
     * origin lists into this SingleList. The origin lists are empty when finished.
     * NOTE: data must not be moved, only nodes.
     *
     * @param left  The first list to combine with this SingleList.
     * @param right The second list to combine with this SingleList.
     */
    public void combine(final SingleList<T> left, final SingleList<T> right) {
        while (left.front != null || right.front != null) {
            if (left.front != null) {
                this.moveFrontToRear(left);
            }
            if (right.front != null) {
                this.moveFrontToRear(right);
            }
        }
        return;
    }

    /**
     * Determines if this SingleList contains key.
     *
     * @param key The key object to look for.
     * @return true if key is in this SingleList, false otherwise.
     */
    public boolean contains(final T key) {
        SingleNode<T> current = this.front;

        while (current != null) {
            if (current.getArtifact().compareTo(key) == 0) {
                return true;
            }
            current = current.getNext();
        }

        return false;
    }

    /**
     * Finds the number of times key appears in list.
     *
     * @param key The object to look for.
     * @return The number of times key appears in this SingleList.
     */
    public int count(final T key) {
        int counter = 0;
        SingleNode<T> current = this.front;

        while (current != null) {
            if (current.getArtifact().compareTo(key) == 0) {
                counter++;
            }
            current = current.getNext();
        }

        return counter;
    }

    /**
     * Finds and returns the object in list that matches key.
     *
     * @param key The object to search for.
     * @return The object that matches key, null otherwise.
     */
    public T find(final T key) {
        SingleNode<T> current = this.front;

        while (current != null) {
            if (current.getArtifact().compareTo(key) == 0) {
                return current.getArtifact();
            }
            current = current.getNext();
        }

        return null;
    }

    /**
     * Get the nth object in this SingleList.
     *
     * @param n The index of the object to return.
     * @return The nth object in this SingleList.
     * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
     */
    public T get(final int n) throws ArrayIndexOutOfBoundsException {
        if (n < 0 || n >= this.length) {
            throw new ArrayIndexOutOfBoundsException("Index " + n + " is out of bounds");
        }

        SingleNode<T> current = this.front;
        for (int i = 0; i < n; i++) {
            current = current.getNext();
        }

        return current.getArtifact();
    }

    /**
     * Determines whether two lists are identical.
     *
     * @param source The list to compare against this SingleList.
     * @return true if this SingleList contains the same objects in the same order
     *         as source, false otherwise.
     */
    public boolean equals(final SingleList<T> source) {
        if (this.length != source.length) {
            return false;
        }

        SingleNode<T> thisCurrent = this.front;
        SingleNode<T> sourceCurrent = source.front;

        while (thisCurrent != null) {
            if (thisCurrent.getArtifact().compareTo(sourceCurrent.getArtifact()) != 0) {
                return false;
            }
            thisCurrent = thisCurrent.getNext();
            sourceCurrent = sourceCurrent.getNext();
        }

        return true;
    }

    /**
     * Finds the first location of a object by key in this SingleList.
     *
     * @param key The object to search for.
     * @return The index of key in this SingleList, -1 otherwise.
     */
    public int index(final T key) {
        SingleNode<T> current = this.front;
        int position = 0;

        while (current != null) {
            if (current.getArtifact().compareTo(key) == 0) {
                return position;
            }
            current = current.getNext();
            position++;
        }

        return -1;
    }

    /**
     * Inserts object into this SingleList at index i. If i greater than the length
     * of this SingleList, append data to the end of this SingleList.
     *
     * @param i        The index to insert the new data at.
     * @param artifact The new object to insert into this SingleList.
     */
    public void insert(int i, final T artifact) {
        if (i >= this.length) {
            // Append to end if index is too large
            this.append(artifact);
            return;
        }

        if (i <= 0) {
            // Prepend if index is 0 or negative
            this.prepend(artifact);
            return;
        }

        // Find the position to insert
        SingleNode<T> current = this.front;
        for (int j = 0; j < i - 1; j++) {
            current = current.getNext();
        }

        // Insert new node after current
        SingleNode<T> newNode = new SingleNode<>(artifact, current.getNext());
        current.setNext(newNode);
        this.length++;

        return;
    }

    /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then objects from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
    public void intersection(final SingleList<T> left, final SingleList<T> right) {
        // Clear this list first
        this.front = null;
        this.rear = null;
        this.length = 0;

        SingleNode<T> leftCurrent = left.front;

        while (leftCurrent != null) {
            T leftArtifact = leftCurrent.getArtifact();

            // Check if this artifact exists in right list
            SingleNode<T> rightCurrent = right.front;
            boolean found = false;

            while (rightCurrent != null && !found) {
                if (rightCurrent.getArtifact().compareTo(leftArtifact) == 0) {
                    found = true;
                }
                rightCurrent = rightCurrent.getNext();
            }

            // If found in both lists and not already in this list, add it
            if (found && !this.contains(leftArtifact)) {
                this.append(leftArtifact);
            }

            leftCurrent = leftCurrent.getNext();
        }

        return;
    }

    /**
     * Finds the maximum object in this SingleList.
     *
     * @return The maximum object.
     */
    public T max() {
        if (this.front == null) {
            return null;
        }

        T maxValue = this.front.getArtifact();
        SingleNode<T> current = this.front.getNext();

        while (current != null) {
            if (current.getArtifact().compareTo(maxValue) > 0) {
                maxValue = current.getArtifact();
            }
            current = current.getNext();
        }

        return maxValue;
    }

    /**
     * Finds the minimum object in this SingleList.
     *
     * @return The minimum object.
     */
    public T min() {
        if (this.front == null) {
            return null;
        }

        T minValue = this.front.getArtifact();
        SingleNode<T> current = this.front.getNext();

        while (current != null) {
            if (current.getArtifact().compareTo(minValue) < 0) {
                minValue = current.getArtifact();
            }
            current = current.getNext();
        }

        return minValue;
    }

    /**
     * Inserts object into the front of this SingleList.
     *
     * @param artifact The object to insert into the front of this SingleList.
     */
    public void prepend(final T artifact) {
        SingleNode<T> newNode = new SingleNode<>(artifact, this.front);
        this.front = newNode;

        if (this.rear == null) {
            // List was empty
            this.rear = newNode;
        }

        this.length++;
        return;
    }

    /**
     * Finds, removes, and returns the object in this SingleList that matches key.
     *
     * @param key The object to search for.
     * @return The object matching key, null otherwise.
     */
    public T remove(final T key) {
        if (this.front == null) {
            return null;
        }

        // Check if first node contains the key
        if (this.front.getArtifact().compareTo(key) == 0) {
            return this.removeFront();
        }

        // Search for the node to remove
        SingleNode<T> previous = this.linearSearch(key);

        if (previous == null || previous.getNext() == null) {
            // Key not found
            return null;
        }

        // Remove the node after previous
        SingleNode<T> nodeToRemove = previous.getNext();
        T artifact = nodeToRemove.getArtifact();
        previous.setNext(nodeToRemove.getNext());

        // Update rear if we removed the last node
        if (nodeToRemove == this.rear) {
            this.rear = previous;
        }

        this.length--;
        return artifact;
    }

    /**
     * Removes the object at the front of this SingleList.
     *
     * @return The object at the front of this SingleList.
     */
    public T removeFront() {
        if (this.front == null) {
            return null;
        }

        T artifact = this.front.getArtifact();
        this.front = this.front.getNext();

        if (this.front == null) {
            // List is now empty
            this.rear = null;
        }

        this.length--;
        return artifact;
    }

    /**
     * Finds and removes all objects in this SingleList that match key.
     *
     * @param key The object to search for.
     */
    public void removeMany(final T key) {
        // Remove from front while front matches key
        while (this.front != null && this.front.getArtifact().compareTo(key) == 0) {
            this.removeFront();
        }

        if (this.front == null) {
            return; // List is now empty
        }

        // Remove from rest of list
        SingleNode<T> current = this.front;
        while (current.getNext() != null) {
            if (current.getNext().getArtifact().compareTo(key) == 0) {
                SingleNode<T> nodeToRemove = current.getNext();
                current.setNext(nodeToRemove.getNext());

                // Update rear if we removed the last node
                if (nodeToRemove == this.rear) {
                    this.rear = current;
                }

                this.length--;
            } else {
                current = current.getNext();
            }
        }

        return;
    }

    /**
     * Reverses the order of the objects in this SingleList.
     */
    public void reverse() {
        if (this.front == null || this.front.getNext() == null) {
            return; // Empty list or single element
        }

        SingleNode<T> previous = null;
        SingleNode<T> current = this.front;
        this.rear = this.front; // Old front becomes new rear

        while (current != null) {
            SingleNode<T> next = current.getNext();
            current.setNext(previous);
            previous = current;
            current = next;
        }

        this.front = previous; // Previous becomes new front
        return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move object or call the high-level methods insert
     * or remove. this SingleList is empty when done. The first half of this
     * SingleList is moved to left, and the last half of this SingleList is moved to
     * right. If the resulting lengths are not the same, left should have one more
     * object than right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void split(final SingleList<T> left, final SingleList<T> right) {
        int totalLength = this.length;
        int leftSize = (totalLength + 1) / 2; // Left gets extra if odd length

        // Move first half to left
        for (int i = 0; i < leftSize && this.front != null; i++) {
            left.moveFrontToRear(this);
        }

        // Move remaining to right
        while (this.front != null) {
            right.moveFrontToRear(this);
        }

        return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move object or call the high-level methods insert
     * or remove. this SingleList is empty when done. Nodes are moved alternately
     * from this SingleList to left and right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {
        boolean toLeft = true;

        while (this.front != null) {
            if (toLeft) {
                left.moveFrontToRear(this);
            } else {
                right.moveFrontToRear(this);
            }
            toLeft = !toLeft; // Alternate between left and right
        }

        return;
    }

    /**
     * Creates a union of two other SingleLists into this SingleList. Copies object
     * to this list. left and right SingleLists are unchanged. Values from left are
     * copied in order first, then objects from right are copied in order.
     *
     * @param left  The first SingleList to create a union from.
     * @param right The second SingleList to create a union from.
     */
    public void union(final SingleList<T> left, final SingleList<T> right) {
        // Clear this list first
        this.front = null;
        this.rear = null;
        this.length = 0;

        // Add all elements from left list
        SingleNode<T> leftCurrent = left.front;
        while (leftCurrent != null) {
            this.append(leftCurrent.getArtifact());
            leftCurrent = leftCurrent.getNext();
        }

        // Add elements from right list that aren't already in this list
        SingleNode<T> rightCurrent = right.front;
        while (rightCurrent != null) {
            if (!this.contains(rightCurrent.getArtifact())) {
                this.append(rightCurrent.getArtifact());
            }
            rightCurrent = rightCurrent.getNext();
        }

        return;
    }
}
